-- MySQL dump 10.13  Distrib 5.6.33-79.0, for Linux (x86_64)
--
-- Host: localhost    Database: vfmobo6d_aria2_remote
-- ------------------------------------------------------
-- Server version	5.6.33-79.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` tinyint(4) NOT NULL,
  `host_id` int(11) NOT NULL,
  `gid` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `system_status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`system_status`) VALUES (1);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts`
--

DROP TABLE IF EXISTS `hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `nick` varchar(50) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts`
--

LOCK TABLES `hosts` WRITE;
/*!40000 ALTER TABLE `hosts` DISABLE KEYS */;
INSERT INTO `hosts` (`id`, `name`, `status`, `nick`, `insertion_date_time`, `modification_date_time`) VALUES (5,'PRISM2J-PC',1,'PRISM2J-PC','2018-04-27 16:59:51','2018-05-11 16:51:54'),(6,'PRISM1-PC',1,'PRISM1-PC','2018-04-30 15:41:31','2018-05-12 18:25:12'),(7,'DK-PC',1,'DK-PC','2018-05-10 11:20:41','2018-05-10 13:39:20');
/*!40000 ALTER TABLE `hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `gid` varchar(150) NOT NULL,
  `host_id` int(11) NOT NULL DEFAULT '6',
  `percentage` double NOT NULL,
  `status` tinyint(4) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL,
  `current_status` varchar(1500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `url`, `gid`, `host_id`, `percentage`, `status`, `insertion_date_time`, `modification_date_time`, `current_status`) VALUES (2,'https://dl.google.com/dl/android/studio/install/3.1.2.0/android-studio-ide-173.4720617-windows.exe','7aa095180b3cb4a9',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:29',''),(3,'https://dl.google.com/dl/android/studio/install/3.1.2.0/android-studio-ide-173.4720617-mac.dmg','5b19ed37106486c0',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:29',''),(4,'https://dl.google.com/dl/android/studio/ide-zips/3.1.2.0/android-studio-ide-173.4720617-linux.zip','0c0bcd297e14b1f5',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:29',''),(5,'https://github.com/shibayan/iislua/releases/download/v0.6.1/iislua_x64.msi','9b89d10d2556468e',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:46',''),(6,'http://releases.ubuntu.com/18.04/ubuntu-18.04-desktop-amd64.metalink','30fffe01046d65da',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:47',''),(7,'http://releases.ubuntu.com/18.04/ubuntu-18.04-live-server-amd64.metalink','9cb915cdfc202e72',5,0,1,'0000-00-00 00:00:00','2018-04-28 13:01:47',''),(8,'https://bitnami.com/redirect/to/185778/bitnami-wampstack-7.1.16-0-windows-x64-installer.exe','b25fb290cb5af868',6,0,1,'0000-00-00 00:00:00','2018-04-30 15:42:33',''),(9,'https://download.microsoft.com/download/B/6/E/B6EA1BCF-6418-47D7-9B73-81C736F7A5DF/iso_windowssdk/17134.12.180419-0858.rs4_release_svc_prod2_WindowsSDK.iso','9de7ea1ecd92abae',6,0,1,'0000-00-00 00:00:00','2018-05-02 13:59:24',''),(10,'https://software-download.microsoft.com/pr/Windows_InsiderPreview_InboxApps_en-us_17025.iso?t=b4b5ec37-6845-45b1-b347-6317025c3a2c&e=1525455170&h=28a51d962cb8ed96a7f93b0c99e2accb','a2f273e8ba9964c5',6,0,1,'0000-00-00 00:00:00','2018-05-04 09:40:32',''),(11,'https://dl.google.com/dl/android/studio/ide-zips/3.2.0.12/android-studio-ide-181.4749738-windows.zip','5123530667fe9630',6,0,1,'0000-00-00 00:00:00','2018-05-04 09:40:33',''),(12,'http://download3.navicat.com/download/navicat120_premium_en_x64.exe','f09aba858d894810',6,0,1,'0000-00-00 00:00:00','2018-05-05 08:55:01',''),(13,'http://download3.navicat.com/monitor-download/windows/navicatmonitor1.2.1.exe','05c87d0679835b97',6,0,1,'0000-00-00 00:00:00','2018-05-05 08:55:02',''),(14,'http://download3.navicat.com/download/modeler021_en_x64.exe','28928fd7bc5ffbfa',6,0,1,'0000-00-00 00:00:00','2018-05-05 08:55:02',''),(15,'http://download3.navicat.com/download/rviewer_en_x64.exe','e6ee5239322c9421',6,0,1,'0000-00-00 00:00:00','2018-05-05 08:55:02',''),(18,'https://github.com/XhmikosR/notepad2-mod/releases/download/4.2.25.998/Notepad2-mod.4.2.25.998.exe','c272498b2659b6f4',6,0,1,'2018-05-04 23:35:28','2018-05-05 08:55:02',''),(21,'https://go.microsoft.com/fwlink/?Linkid=852155','ae0b59d536bcac74',6,0,1,'2018-05-04 23:51:41','2018-05-05 08:55:02',''),(22,'https://freefilesync.org/download/FreeFileSync_10.0_Windows_Setup.exe','0cd5fd02d19b2858',6,0,1,'2018-05-05 11:02:17','2018-05-05 11:06:56',''),(23,'https://freefilesync.org/download/FreeFileSync_10.0_macOS.zip','55afdc88eedf883c',6,0,1,'2018-05-05 11:02:27','2018-05-05 11:06:56',''),(24,'https://freefilesync.org/download/FreeFileSync_10.0_Ubuntu_17.10_64-bit.tar.gz','d4ff324abe684ed3',6,0,1,'2018-05-05 11:02:39','2018-05-05 11:06:56',''),(25,'https://freefilesync.org/download/FreeFileSync_10.0_Source.zip','8d212d4276210feb',6,0,1,'2018-05-05 11:02:49','2018-05-05 11:06:57',''),(26,'https://www.crystalidea.com/downloads/uninstalltool_setup.exe','ea9547118b53ff3e',6,0,1,'2018-05-05 11:06:39','2018-05-05 11:06:57',''),(27,'https://downloads.sourceforge.net/sourceforge/gnucash/gnucash-3.1.setup.exe','f256b57f657d155c',6,0,1,'2018-05-05 12:45:52','2018-05-05 12:45:57',''),(28,'https://downloads.sourceforge.net/sourceforge/gnucash/gnucash-3.1-1.tar.bz2','19882be57e4de9e0',6,0,1,'2018-05-05 12:46:18','2018-05-05 12:46:57',''),(29,'https://inmusik.co/wp-content/uploads/2018/03/inmusik-wp-v1.09.pdf','bb3087678a4a4538',6,0,1,'2018-05-05 22:33:08','2018-05-07 09:23:18',''),(30,'https://d8.usercdn.com/d/qqlwfm34t6fnf7qj6ltyngkfd4zxrop3y3ag25nmqu3rvjrxrxsj6wxkgpf62dhqqkdhparn/Userscloud-Desktop_File_Manager_Install.exe','395aae2fcc7a8f04',6,0,1,'2018-05-06 10:08:12','2018-05-07 09:23:18',''),(31,'https://allsync.com/d/windows.php','64ac0f6e9308d5ab',6,0,1,'2018-05-06 10:12:51','2018-05-07 09:23:18',''),(32,'https://d4.usercdn.com/d/xmlqqergtsfnf7qjbxgitbkzcj2i475g44wvzwajokeqlo3ilve57snij5drz4y3rdtxgzhw/OF.2016.PP.16.0.4639.1000.May2018.win64.rar','6781d7ba0ffc7b2a',6,0,1,'2018-05-06 10:16:07','2018-05-07 09:23:18',''),(33,'http://down7.dailyuploads.net:182/d/yucbmexdof6mhiantbd6gfcpczmfdvimcnv7jmx4f3gcsyvjmxarj2vn/MindGenius.Business.7.0.1.6925.rar','83f81fe8c22d63f8',6,0,1,'2018-05-06 10:21:44','2018-05-07 09:23:18',''),(34,'https://d7.usercdn.com/d/qil44ergtsfnf7qjbxgi3c2dkixsss4af6wlofetn5ozrv2rbv52dgylt23gibafpcr44ywg/Air.Explorer.2.3.1.rar','fdc440ef5946a9ca',6,0,1,'2018-05-06 10:28:38','2018-05-07 09:23:18',''),(35,'https://d7.usercdn.com/d/qil46ergtsfnf7qjbxgi5bkzd5w6rhaz3wh373rqnd4ls654lne72ujspvy47zjlgcc6siiz/Directory.List.Print.3.46.rar','cf5f5c5b1b5ba5b9',6,0,1,'2018-05-06 10:30:57','2018-05-07 09:23:18',''),(36,'https://www.leadtools.com/rd/v200/LEADTOOLSMain.exe','f809cddf81811ff4',6,0,1,'2018-05-06 10:32:53','2018-05-07 09:23:19',''),(37,'https://www.leadtools.com/rd/v200/LEADTOOLSOCRAdditional.exe','14266fc69889271c',6,0,1,'2018-05-06 10:33:43','2018-05-07 09:23:19',''),(38,'https://www.leadtools.com/rd/v200/OCR_AdditionalLanguages.zip','b251064eae3e089d',6,0,1,'2018-05-06 10:34:05','2018-05-07 09:23:19',''),(39,'https://www.leadtools.com/rd/v200/OCR_EastAsianLanguages.zip','5f7080ed63b1b23b',6,0,1,'2018-05-06 10:34:22','2018-05-07 09:23:19',''),(40,'https://www.leadtools.com/rd/v200/LEADTOOLSVirtualPrinterClient.exe','e35e0d58057ac226',6,0,1,'2018-05-06 10:34:47','2018-05-07 09:23:19',''),(41,'https://www.leadtools.com/rd/v200/LEADTOOLSMultimedia.exe','ee3c7cb7f5b38b4b',6,0,1,'2018-05-06 10:35:38','2018-05-07 09:23:19',''),(42,'http://www.weonlydo.com/Samples/wodCrypt.exe','3c16bef04cf3f2b4',6,0,1,'2018-05-06 10:45:42','2018-05-07 09:23:19',''),(43,'http://www.weonlydo.com/Samples/wodSSH.exe','f5983b4b9adfb896',6,0,1,'2018-05-06 10:45:46','2018-05-07 09:23:19',''),(44,'http://www.weonlydo.com/Samples/wodSFTP.exe','e48003cebd2a9bd4',6,0,1,'2018-05-06 10:45:52','2018-05-07 09:23:20',''),(45,'http://www.weonlydo.com/Samples/wodSSHServer.exe','0424aab7f9fd4030',6,0,1,'2018-05-06 10:45:56','2018-05-07 09:23:20',''),(46,'http://www.weonlydo.com/Samples/wodSSHTunnel.exe','cc901240af8a0104',6,0,1,'2018-05-06 10:46:00','2018-05-07 09:23:32',''),(47,'http://www.weonlydo.com/Samples/wodSFTPdll.exe','d9adcaa52930cf8a',6,0,1,'2018-05-06 10:46:06','2018-05-07 09:23:32',''),(48,'http://www.weonlydo.com/Samples/wodSSH.NET.msi','7c9416bccc19b4ed',6,0,1,'2018-05-06 10:46:11','2018-05-07 09:23:32',''),(49,'http://www.weonlydo.com/Samples/wodSFTP.NET.msi','5e73e6f067ea5cb0',6,0,1,'2018-05-06 10:46:18','2018-05-07 09:23:32',''),(50,'http://www.weonlydo.com/Samples/wodFtpDLX.NET.msi','5c2c793e2aa238d8',6,0,1,'2018-05-06 10:46:21','2018-05-07 09:23:32',''),(51,'http://www.weonlydo.com/Samples/wodWebServer.NET.msi','c0f539186ce37f62',6,0,1,'2018-05-06 10:46:27','2018-05-07 09:23:32',''),(52,'http://www.weonlydo.com/Samples/wodAppUpdate.exe','164f7e69b7fd364f',6,0,1,'2018-05-06 10:46:33','2018-05-07 09:23:32',''),(53,'http://www.weonlydo.com/Samples/wodHttpDLX.exe','fa7c398e8b16e09c',6,0,1,'2018-05-06 10:46:36','2018-05-07 09:23:33',''),(54,'http://www.weonlydo.com/Samples/wodFtpDLX.exe','6a92f5d6be841a5f',6,0,1,'2018-05-06 10:46:42','2018-05-07 09:23:33',''),(55,'http://www.weonlydo.com/Samples/wodTelnetDLX.exe','d338c6da54c93915',6,0,1,'2018-05-06 10:46:49','2018-05-07 09:23:33',''),(56,'http://www.weonlydo.com/Samples/wodFTPServer.exe','b4080b65ce9e2723',6,0,1,'2018-05-06 10:46:53','2018-05-07 09:23:33',''),(57,'http://www.weonlydo.com/Samples/wodWebServer.exe','9e52a6fc20bfd976',6,0,1,'2018-05-06 10:46:57','2018-05-07 09:23:33',''),(58,'http://www.weonlydo.com/Samples/wodVPN.exe','b078f49d251d84d2',6,0,1,'2018-05-06 10:47:01','2018-05-07 09:23:33',''),(59,'http://www.weonlydo.com/Samples/wodXMPP.exe','411d25dbf643cc3a',6,0,1,'2018-05-06 10:47:06','2018-05-07 09:23:33',''),(60,'http://www.weonlydo.com/Samples/wodMailbox.exe','761de2ab21e1e661',6,0,1,'2018-05-06 10:47:11','2018-05-07 09:23:34',''),(61,'http://www.weonlydo.com/Samples/wodImapServer.exe','1344cac71cebb6a9',6,0,1,'2018-05-06 10:47:15','2018-05-07 09:23:34',''),(62,'http://www.weonlydo.com/Samples/wodSmtpServer.exe','561835029af02e98',6,0,1,'2018-05-06 10:47:19','2018-05-07 09:23:34',''),(63,'http://www.weonlydo.com/Samples/wodPop3Server.exe','82e9a14b2232fd52',6,0,1,'2018-05-06 10:47:24','2018-05-07 09:23:34',''),(64,'http://www.weonlydo.com/Samples/wodSmtp.exe','36e0f9324f57017a',6,0,1,'2018-05-06 10:47:29','2018-05-07 09:23:34',''),(65,'http://www.weonlydo.com/Samples/wodPop3.exe','8fb22dea982cea16',6,0,1,'2018-05-06 10:47:33','2018-05-07 09:23:34',''),(66,'http://www.weonlydo.com/Samples/wodBeep.exe','6b0d65973a4865ab',6,0,1,'2018-05-06 10:47:37','2018-05-07 09:23:34',''),(67,'http://www.weonlydo.com/Samples/wodDHCPServer.exe','35cbf104b6c8a2cc',6,0,1,'2018-05-06 10:47:42','2018-05-07 09:23:35',''),(68,'http://www.weonlydo.com/Samples/wodShellMenu.exe','d00daf52806d5e79',6,0,1,'2018-05-06 10:47:46','2018-05-07 09:23:35',''),(69,'https://www.termius.com/download/windows/Termius.exe','57ec3f834e62cec2',6,0,1,'2018-05-06 10:53:53','2018-05-07 09:23:35',''),(70,'https://d1vhcvzji58n1j.cloudfront.net/pop-os/iso/18.04/amd64/intel/21/pop-os_18.04_amd64_intel_21.iso','b6e40d75d264304c',6,0,1,'2018-05-06 11:16:49','2018-05-07 09:23:35',''),(71,'https://github.com/gojuno/mainframer/releases/download/v2.1.0/mainframer.sh','dea72e4d3f8403ee',6,0,1,'2018-05-06 11:37:46','2018-05-07 09:23:35',''),(72,'https://plugins.jetbrains.com/plugin/download?rel=true','d0af98ceda9124ad',6,0,1,'2018-05-06 11:39:33','2018-05-07 09:23:35',''),(74,'http://188.138.68.26/Getintopc.com/Autodesk_AutoCAD_2019.0.1_Update_Onlyx64.zip?md5=IPbVcPKzjAn5JCdZk5Zr1Q&expires=1526311223','d4de1c90637aae21',6,0,1,'0000-00-00 00:00:00','2018-05-07 09:23:35',''),(75,'http://188.138.68.26/Getintopc.com/WinAutomation_Professional_Plus_7.0.2.4695.zip?md5=3aMwU8Pprxtuw7t36vhJ9w&expires=1526311721','5f5b7b8b6175cb78',6,0,1,'0000-00-00 00:00:00','2018-05-07 09:23:35',''),(76,'https://static.tenable.com/marketing/nessus-letter.pdf','3857ea6326938d56',6,0,1,'2018-05-06 13:22:57','2018-05-07 09:23:36',''),(77,'http://dl.greenbone.net/download/VM/gsm_ce_4.2.10.iso','503318aa1b170c3d',6,0,1,'2018-05-06 13:27:10','2018-05-07 09:23:36',''),(78,'https://github.com/Genymobile/scrcpy/releases/download/v1.1/scrcpy-windows-with-deps-v1.1.zip','2e70e47a48a31835',6,0,1,'2018-05-06 15:03:31','2018-05-07 09:23:36',''),(79,'https://download.documentfoundation.org/libreoffice/stable/6.0.3/win/x86_64/LibreOffice_6.0.3_Win_x64.msi.torrent','ea0db3324745fe29',6,0,1,'2018-05-06 22:44:38','2018-05-07 09:23:36',''),(80,'https://download.documentfoundation.org/libreoffice/stable/6.0.3/win/x86_64/LibreOffice_6.0.3_Win_x64_helppack_en-GB.msi.torrent','7cd583792bc900a8',6,0,1,'2018-05-06 22:44:55','2018-05-07 09:23:36',''),(81,'https://download.documentfoundation.org/libreoffice/stable/6.0.3/win/x86_64/LibreOffice_6.0.3_Win_x64_sdk.msi.torrent','e9ba8f2cbdaf91bb',6,0,1,'2018-05-06 22:45:20','2018-05-07 09:23:36',''),(82,'https://download.documentfoundation.org/libreoffice/src/6.0.3/libreoffice-6.0.3.2.tar.xz.torrent','b0f9624b3f5d37b5',6,0,1,'2018-05-06 22:45:27','2018-05-07 09:23:36',''),(83,'https://download.documentfoundation.org/libreoffice/src/6.0.3/libreoffice-dictionaries-6.0.3.2.tar.xz.torrent','1f49a473ca2aca35',6,0,1,'2018-05-06 22:45:32','2018-05-07 09:23:36',''),(84,'https://download.documentfoundation.org/libreoffice/src/6.0.3/libreoffice-help-6.0.3.2.tar.xz.torrent','302a5aaa4dc1a462',6,0,1,'2018-05-06 22:45:37','2018-05-07 09:23:37',''),(85,'https://download.documentfoundation.org/libreoffice/src/6.0.3/libreoffice-translations-6.0.3.2.tar.xz.torrent','52b45e1ee3f65895',6,0,1,'2018-05-06 22:45:45','2018-05-07 09:23:37',''),(86,'https://files.gpg4win.org/gpg4win-3.1.1.tar.bz2','4d97e4ac5859c725',6,0,1,'2018-05-06 22:46:58','2018-05-07 09:23:37',''),(87,'https://files.gpg4win.org/gpg4win-3.1.1.exe','9ecf754b547a523c',6,0,1,'2018-05-06 22:47:51','2018-05-07 09:23:37',''),(88,'https://github.com/shiftkey/desktop/releases/download/release-1.1.1/GitHubDesktop-linux-x86_64-1.1.1.AppImage','e2046e3ab9cc1025',6,0,1,'2018-05-06 22:57:30','2018-05-07 09:23:37',''),(89,'https://github.com/darealshinji/vlc-AppImage/releases/download/2.2.8/VLC-2.2.8.glibc2.16-x86_64.AppImage','79f281b45c43243d',6,0,1,'2018-05-06 22:57:46','2018-05-07 09:23:37',''),(90,'https://libreoffice.soluzioniopen.com/stable/fresh/LibreOffice-fresh.basic-x86_64.AppImage','95396872c1564f97',6,0,1,'2018-05-06 23:00:00','2018-05-07 09:23:37',''),(91,'https://flathub.org/repo/appstream/org.libreoffice.LibreOffice.flatpakref','ddf2a944c8feea35',6,0,1,'2018-05-06 23:01:22','2018-05-07 09:23:38',''),(92,'https://flathub.org/repo/appstream/com.visualstudio.code.flatpakref','0d3fe39ef257dc89',6,0,1,'2018-05-06 23:01:55','2018-05-07 09:23:38',''),(93,'https://flathub.org/repo/appstream/com.google.AndroidStudio.flatpakref','114e799a19a90b9b',6,0,1,'2018-05-06 23:02:47','2018-05-07 09:23:38',''),(94,'http://www.advanced-ip-scanner.com/download/Advanced_IP_Scanner_2.5.3581.exe','fc13697243e00047',6,0,1,'2018-05-07 18:50:57','2018-05-08 09:40:42',''),(95,'http://www.radmin.com/download/Radmin_3.5.2.1_EN.zip','d93d65b2af4ddf1a',6,0,1,'2018-05-07 18:51:32','2018-05-08 09:40:42',''),(96,'https://get.videolan.org/vlc/3.0.2/win64/vlc-3.0.2-win64.exe','b50d578653dac8c7',6,0,1,'2018-05-07 19:03:21','2018-05-08 09:40:42',''),(97,'http://get.videolan.org/vlc/3.0.2/vlc-3.0.2.tar.xz','d05aefaa89a3d0a9',6,0,1,'2018-05-07 19:03:40','2018-05-08 09:40:42',''),(98,'https://www.apachelounge.com/download/VC15/binaries/httpd-2.4.33-win64-VC15.zip','d37b7eb5cb6ac101',6,0,1,'2018-05-07 19:15:16','2018-05-08 09:40:43',''),(99,'https://www.apachelounge.com/download/VC15/modules/mod_fcgid-2.3.9-win64-VC15.zip','2bb51f143de5434e',6,0,1,'2018-05-07 19:19:30','2018-05-08 09:40:43',''),(100,'https://www.apachelounge.com/download/VC15/modules/mod_security-2.9.2-win64-VC15.zip','a573ff2cd7495f37',6,0,1,'2018-05-07 19:20:34','2018-05-08 09:40:43',''),(101,'https://www.apachelounge.com/download/VC15/modules/mod_jk-1.2.43-win64-VC15.zip','150eed4565a913f6',6,0,1,'2018-05-07 19:21:18','2018-05-08 09:40:43',''),(102,'https://www.apachelounge.com/download/VC15/modules/isapi_redirect.dll-1.2.43-VC15.zip','15a007c7b2caba59',6,0,1,'2018-05-07 19:23:48','2018-05-08 09:40:43',''),(103,'https://www.apachelounge.com/download/VC15/modules/mod_xsendfile-1.0-P1-win64-VC15.zip','f77f785ff141e83b',6,0,1,'2018-05-07 19:24:16','2018-05-08 09:40:43',''),(104,'https://www.apachelounge.com/download/VC15/modules/mod_log_rotate-1.00a-win64-VC15.zip','3fa0cb97b601e03e',6,0,1,'2018-05-07 19:24:40','2018-05-08 09:40:43',''),(105,'https://www.apachelounge.com/download/VC15/modules/dbd_modules-1.0.6-win64-VC15.zip','368c4d379055353d',6,0,1,'2018-05-07 19:25:04','2018-05-08 09:40:43',''),(106,'https://www.apachelounge.com/download/VC15/modules/mod_bw-0.92-win64-VC15.zip','3ebbaf8510f59524',6,0,1,'2018-05-07 19:25:31','2018-05-08 09:40:44',''),(107,'https://www.apachelounge.com/download/VC15/modules/mod_view-2.2-win64-VC15.zip','5a21648955724252',6,0,1,'2018-05-07 19:25:48','2018-05-08 09:40:44',''),(108,'https://www.apachelounge.com/download/VC15/modules/mod_watch-4.3-win64-VC15.zip','864059aa163745b2',6,0,1,'2018-05-07 19:26:03','2018-05-08 09:40:44',''),(109,'https://www.apachelounge.com/download/VC15/modules/mod_evasive2-1.10.2-win64-VC15.zip','87acbe5a6ab1c90a',6,0,1,'2018-05-07 19:26:18','2018-05-08 09:40:44',''),(110,'https://download.jetbrains.com/go/goland-2018.1.2.exe','015d186189e296a5',6,0,1,'2018-05-07 21:28:25','2018-05-08 09:40:45',''),(111,'http://bit.ly/2ezPtYR','760a109706b3b899',6,0,1,'2018-05-07 21:54:18','2018-05-08 09:40:45',''),(112,'http://wegraphics.net/wg-downloads/free/web/wg_avenir_coming_soon.zip','3b229ff383ebd3b3',6,0,1,'2018-05-07 21:56:00','2018-05-08 09:40:45',''),(113,'https://dl.google.com/tag/s/appguid%3D%7B8A69D345-D564-463C-AFF1-A69D9E530F96%7D%26iid%3D%7B4800CFBE-8F8C-0EAA-C36C-57302F85B433%7D%26lang%3Den%26browser%3D4%26usagestats%3D0%26appname%3DGoogle%2520Chrome%26needsadmin%3Dtrue%26ap%3Dx64-stable-statsde','162bae160dbb907c',6,0,1,'0000-00-00 00:00:00','2018-05-10 09:39:34',''),(114,'https://dl.google.com/tag/s/appguid%3D%7B8237E44A-0054-442C-B6B6-EA0509993955%7D%26iid%3D%7B4800CFBE-8F8C-0EAA-C36C-57302F85B433%7D%26lang%3Den%26browser%3D4%26usagestats%3D0%26appname%3DGoogle%2520Chrome%2520Beta%26needsadmin%3Dtrue%26ap%3D-arch_x64','9b329fddbfd2736e',6,0,1,'0000-00-00 00:00:00','2018-05-10 09:39:34',''),(115,'https://dl.google.com/dl/edgedl/chrome/policy/policy_templates.zip?_ga=2.251023942.1798701118.1525758569-593670117.1525758348','7dc6d3459201c7e9',6,0,1,'0000-00-00 00:00:00','2018-05-10 09:39:35',''),(116,'http://prdownloads.sourceforge.net/scons/scons-3.0.1-setup.exe','22ea08d1ba224f16',6,0,1,'2018-05-09 11:25:59','2018-05-10 09:39:35',''),(117,'https://dl.bintray.com/boostorg/release/1.67.0/source/boost_1_67_0.7z','708c96fbcf1a6ccc',6,0,1,'2018-05-09 11:26:35','2018-05-10 09:39:35',''),(118,'http://www.pdf995.com/samples/pdf.pdf','670e7c7088dec174',7,0,1,'0000-00-00 00:00:00','2018-05-10 12:21:38',''),(119,'http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf','8d4d351966b2c632',7,0,1,'0000-00-00 00:00:00','2018-05-10 13:41:06','{\r\n  \"id\": \"119\",\r\n  \"jsonrpc\": \"2.0\",\r\n  \"result\": {\r\n    \"bitfield\": \"80\",\r\n    \"completedLength\": \"7945\",\r\n    \"connections\": \"0\",\r\n    \"dir\": \"C:\\Programs\\aria2_repository\\tasks\",\r\n    \"downloadSpeed\": \"0\",\r\n    \"errorCode\": \"0\",\r\n    \"errorMessage\": \"\",\r\n    \"files\": [\r\n      {\r\n        \"completedLength\": \"7945\",\r\n        \"index\": \"1\",\r\n        \"length\": \"7945\",\r\n        \"path\": \"C:/Programs/aria2_repository/tasks/pdf-sample.pdf\",\r\n        \"selected\": \"true\",\r\n        \"uris\": [\r\n          {\r\n            \"status\": \"used\",\r\n            \"uri\": \"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf\"\r\n          },\r\n          {\r\n            \"status\": \"waiting\",\r\n            \"uri\": \"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf\"\r\n          },\r\n          {\r\n            \"status\": \"waiting\",\r\n            \"uri\": \"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf\"\r\n          },\r\n          {\r\n            \"status\": \"waiting\",\r\n            \"uri\": \"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf\"\r\n          },\r\n          {\r\n            \"status\": \"waiting\",\r\n            \"uri\": \"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf\"\r\n          }\r\n        ]\r\n      }\r\n    ],\r\n    \"gid\": \"8d4d351966b2c632\",\r\n    \"numPieces\": \"1\",\r\n    \"pieceLength\": \"1048576\",\r\n    \"status\": \"complete\",\r\n    \"totalLength\": \"7945\",\r\n    \"uploadLength\": \"0\",\r\n    \"uploadSpeed\": \"0\"\r\n  }\r\n}'),(120,'http://www.africau.edu/images/default/sample.pdf','',7,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',''),(121,'https://downloads.mixxx.org/mixxx-2.1.0/mixxx-2.1.0-win64.exe','55ffa0d5d3a546f8',6,0,1,'2018-05-11 21:42:09','2018-05-12 13:51:42',''),(122,'https://downloads.sourceforge.net/project/sqliteman/sqliteman/1.2.2/Sqliteman-1.2.2-win32.zip?r=https%3A%2F%2Fsourceforge.net%2Fprojects%2Fsqliteman%2Ffiles%2Fsqliteman%2F1.2.2%2FSqliteman-1.2.2-win32.zip%2Fdownload%3Fuse_mirror%3Dexcellmedia%26r%3Dh','',6,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',''),(123,'https://product-dist.ballerina.io/downloads/0.970.1/ballerina-platform-windows-installer-x64-0.970.1.msi','',6,0,0,'2018-05-13 22:22:00','0000-00-00 00:00:00',''),(124,'https://product-dist.ballerina.io/downloads/0.970.1/ballerina-vscode-plugin-0.970.1.vsix','',6,0,0,'2018-05-13 22:22:22','0000-00-00 00:00:00',''),(129,'https://plugins.jetbrains.com/plugin/download?rel=true&updateId=45756','',6,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vfmobo6d_aria2_remote'
--

--
-- Dumping routines for database 'vfmobo6d_aria2_remote'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-13 17:57:55
